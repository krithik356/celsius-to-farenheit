c=float(input())
f=c*9/5+32
print(f)